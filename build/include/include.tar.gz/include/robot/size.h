#ifndef _ROBOT_SIZE_H_
#define _ROBOT_SIZE_H_

#define MAX_JOBNAME_STR_LENTH 	31
#define MAX_LABEL_STR_LENTH 	31

#define MAX_LABEL_SIZE			MAX_LABEL_STR_LENTH+1		//max label size
#define MAX_JOBNAME_SIZE		MAX_JOBNAME_STR_LENTH+1		//max JOB filename size

#endif
