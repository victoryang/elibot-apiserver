#ifndef MOVE_ML_H
#define MOVE_ML_H

void ResetMovtIntpProgram(void);  //Î¢¶Î²å²¹³ÌÐò¸´Î»
int MovtInterpolationApi(MoveData_t *md ,unsigned char is_measure);

#endif // MOVE_ML_H

